Integrantes del grupo:


FELIPE CUADROS, ISABELLA SANDOVAL Y ANDRES FELIPE GARCIA

entrega 1 commits de calidad


commits de calidad de issa04-sand o de Isabella Sandoval Montaño

id de el commit de issa04-sand (Isabella) del escenario 1 y sus pruebas 62564d8aa9fde591a5518337b4615ed00c14a610  , con  la descripción o titulo del commit es la siguiente: " Se agrega la codificación de los casos de prueba de setupStage1 "

id de el commit de issa04-sand (Isabella) del escenario 2   y sus pruebas 1773d6eae9bc1a25de40bdb795742d51786f766e, con  la descripción o titulo del commit es la siguiente: " Se agrega la codificación de los casos de prueba de setupStage2 y  setupStage3"

id de el commit de issa04-sand (Isabella) del escenario 3   y sus pruebas 1773d6eae9bc1a25de40bdb795742d51786f766e, con  la descripción o titulo del commit es la siguiente: " Se agrega la codificación de los casos de prueba de setupStage2 y  setupStage3"

id de el commit de issa04-sand (Isabella) de la entrega de requerimientos solo los de  dorfman: c0db7854dd0ccea36ac1cf289ae2f26f9ea1afdf, con  la descripción o titulo del commit es la siguiente: " Se sube analisis de requerimientos”


id de el commit de issa04-sand (Isabella) de la entrega de requerimientos de la manera tabulado en donde para cada requerimiento se hace la tabla: df8ae9d4178add4db86d06eb59b8596452d01ae4, con  la descripción o titulo del commit es la siguiente: " docs: agrega análisis de requerimientos por especificación (PDF)”

Entrega 2 commits

id de el commit de issa04-sand (Isabella) de la entrega del algoritmo de búsqueda binaria: 9bbea6a817ac79c5032a0290a95e5ad66e901435, con la descripción o titulo del commit es la siguiente: " Se sube el algoritmo de busqueda binaria"

id de el commit de issa04-sand (Isabella) de la entrega del algoritmo de insercion: e5b2ed369350bb2711d492621ca3cd0979c51155, con la descripción o titulo del commit es la siguiente: " Se sube el algoritmo de insercion"

id de el commit de issa04-sand (Isabella) de la entrega del algoritmo de búsqueda lineal: 050e87f0824a26e71b850a746d106d0ea2e50361, con la descripción o titulo del commit es la siguiente: " Se sube el metodo del algortimo de busqueda lineal"

id de el commit de issa04-sand (Isabella) de la entrega del algoritmo de bubble Sort: a234d19bf70b191601ccd46c6ff1a0c85121bc1d, con la descripción o titulo del commit es la siguiente: " Se sube el metodo del algortimo de bubble Sort"

id de el commit de issa04-sand (Isabella) de la entrega de las clases listEnemy, NodeEnemy y TypeEnemy: 3fdd7b6b8b305afcdd619596d6fe5dbac9ede6c3, con la descripción o titulo del commit es la siguiente: " Se sube las clases listEnemy, NodeEnemy y TypeEnemy "

id de el commit de issa04-sand (Isabella) de la entrega del métodos agregar y eliminar: d8ac39ffc5d2f0354b880e78dc1d1fd608ab6448, con la descripción o titulo del commit es la siguiente: " Se suben los metodos de agregar y borrar "

id de el commit de issa04-sand (Isabella) de la entrega se sube el metodo printList, se corrige y se agrega un metodo de la clase Enemy: 0b6888af6f918fc2b206435abbe4e95357bf3088, con la descripción o titulo del commit es la siguiente: " se sube el metodo printList, se corrige y se agrega un metodo de la clase Enemy "

id de el commit de issa04-sand (Isabella) de la entrega se sube la clase Arms con su enumeracion: 3a67e15aa118c6ce3700a6b2ab763010fbce70a3, con la descripción o titulo del commit es la siguiente: " Se sube la clase Arms con su enumeracion "



COMMITS DE CALIDAD DE ANDRES FELIPE GARCIA BARRERO O supj4k

id de el commit de supj4k (andres) del escenario 4 y sus pruebas  ef756ae525298a28e8c63682f6ca40ecfd1c41f4, la descripción o titulo del commit es la siguiente: "creacion del escenario 4 con sus 2 casos de prueba"


id de el commit de supj4k (andres) del escenario 5 y sus pruebas  4e1ca2eb05f9f2cc1e31c83914cbd8b4d87c006c, la descripción o titulo del commit es la siguiente: "pruebas de el escenario 5 con sus correspondientes pruebas"


id de el commit de supj4k (andres) del escenario 6 y sus pruebas  222c5eae4c4398cf7f55bd1d8dda53b9f597a547, la descripción del commit o titulo es la siguiente: "codificacion del escenario 6 y con sus pruebas correspondientes"


id de el commit de supj4k (andres) de la entrega del diagrama UML: 36668dc46d3c53f0b1cbc1a807e5a5990df27c58, la descripción o titulo del commit es la siguiente: "entrega del diagrama UML de oregon trail, con su archivo en visual paradim y con imagen"

ENTREGA #2


COMMITS DE CALIDAD DE ANDRES FELIPE GARCIA O supj4k


id de el commit de supj4k (Andres) "239738fab8f5a1e04e834943e07179eac023e0ad", su descripcion o titulo: "subida de todas la pruebas hechas en la primera entrega a mi rama, ademas de la creacion de la clase achivement o logros, con su constructores y getters y setters"


id de el commit de supj4k (Andres) "fe738a1f8464da6bedd67d89d3a54eec723e5bc7", su descripcion o titulo: "subida de la creacion de las clases del nodo de logros con sus getters, setters y constructor, y de la clase arbol de logros"


id de el commit de supj4k (Andres) "a296bfa44a9bb783152876e6554f90b2fc7812e9", su descripcion o titulo: "subida de la creacion del metodo de agregar o insertar en el arbol de player"


id de el commit de supj4k (Andres) "e260e5fb183c7bc168bc59083d0f539788914919", su descripcion o titulo: "creacion del metodo search en la clase treeachivement, y arreglo de las pruebas de logros"


id de el commit de supj4k (Andres) "25e6d6ff2458ac5a302ee0a25074d45dc7b40062", su descripcion o titulo: "subida o creacion de los metodos de inorden para el arbol del jugador y el arbol de todo los logros posibles, y el toString de Achivement"


id de el commit de supj4k (Andres) "466ed58f5c7a0567acae92404763df9f39b8dad9", su descripcion o titulo: "subida de los metodos para insertar o agregar al arbol de todos los logros de forma automatica en oregonTrail y la creacion del metodo insertar todos los logros en treeachivement"


id de el commit de supj4k (Andres) "035607a6528f9f919daec01aa017f73821591431", su descripcion o titulo: "creacion de la clase spawner con todos sus atributos y demas, ademas se crea el spawn pos la cual, guarda en un objecto los pos X y Y; y de ultimo cambios en las pruebas de spawner para que sean correctas"

commits de calidad de WertyDeluxe o de Felipe Cuadros Muñoz

id de el commit de WertyDeluxe (Felipe) de la estructura LinkedList y una clase Nodo generica, adicional, retoques en la clase Test de InventoryTest para que pueda correr cf55a68350fc49f920dd0e43d5737129267bc1bd, la descripcion o titulo del commit es la siguiente: feat<structures>: "Implementacion LinkedList y Node + retoques InventoryTest"

id de el commit de WertyDeluxe (Felipe) del escenario 9, sus pruebas y la configuración de la dependencia de JUnit e4d0a7da4f9d3286cee2701cfe6b8229f8e0bb01, la descripcion o titulo del commit es la siguiente: "<feat>add: Prueba unitaria setupstage9 + configuracion dependencia junit"

id de el commit de WertyDeluxe (Felipe) del escenario 7 y sus pruebas 5fc5749b1c137d446f4f2efff95e0278f1123710, la descripcion o titulo del commit es la siguiente: "<feat>add: Prueba unitaria setupstage7"

id de el commit de WertyDeluxe (Felipe) del escenario 8, sus pruebas y la estructura de carpetas en Intelij 04c42ea9a75356110bb27e843d0d0a69466aa475, la descripcion o titulo del commit es la siguiente: "<feat>add: Prueba unitaria setupstage8 y file structure"

id de el commit de WertyDeluxe (Felipe) del escenario de casos de uso y diseño de casos de prueba en pdf dbc782ba905a8ddd383883e776d2377eb07c5de1, la descripcion o titulo del commit es la siguiente: "<feat>add: Escenarios y diseño de casos de prueba"








id de el commit de supj4k (Andres) "0200521fc0c23e5cd436ee44e73c8a0c56ba172f", su descripcion o titulo: "entrega del diagrama de clases actualizado para la segunda entrega, co el patron MVC sin metodos en los controllers"


id de el commit de supj4k (Andres) "08275e6ddfe63d4f99549843f9f0812c7a3d6e78 su descripcion o titulo: "comentarios o contratos restantes de los metodos de treeachivementes y definir la estructura del arbol de todos los logros"
