package model;

public enum TypeEnemy {

    ENEMY_WITH_KNIFE,
    ENEMY_WITH_RIFLE,
    ENEMY_WITH_REVOLVER;
}
