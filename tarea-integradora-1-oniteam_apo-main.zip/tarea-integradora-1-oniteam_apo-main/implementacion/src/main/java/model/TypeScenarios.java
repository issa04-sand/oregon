package model;

public enum TypeScenarios {
    START,
    ROAD,
    RIVER
}
