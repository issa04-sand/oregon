package model;

public enum EnemyState {
    IDLE,
    PERSEGUIR
}
