package model;

public enum TypeItem {
    COMIDA,
    MEDICINA,
    MUNICION
}
