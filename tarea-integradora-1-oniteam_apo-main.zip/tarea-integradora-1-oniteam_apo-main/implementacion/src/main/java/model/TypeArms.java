package model;

public enum TypeArms {
    RIFLE, REVOLVER;
}
